#include<stdio.h>
#include<stdlib.h>
#include<../include/tools.h>
FILE *fp,*hspbin;
int local[15],memory[65535]={0},program[65535]={0};
char file[255]={0};
int script(){
	scanf("%s",&file);
	hspcompile(file);
	if(fopen(file,"r")==0)return -1;
	hspbin=fopen(file,"r");
	local[1]=0;
	while(!feof(hspbin))
		program[local[1]++]=fgetc(hspbin);
	for(program[0]=0;program[0]<0xffff;program[0]++)
		if(program[program[0]]==0xff)while(program[++program[0]]!=0xff);
		else if(program[program[0]]==0x1)program[program[++program[0]]]+=program[program[++program[0]]];
		else if(program[program[0]]==0x2)program[program[++program[0]]]-=program[program[++program[0]]];
		else if(program[program[0]]==0x3)local[0]++;
		else if(program[program[0]]==0x4)local[0]--;
		else if(program[program[0]]==0x11)program[program[++program[0]]]=program[++program[0]];
		else if(program[program[0]]==0x12)program[program[++program[0]]]=program[program[++program[0]]];
		else if(program[program[0]]==0x13)program[0]=program[program[++program[0]]]-1;
		else if(program[program[0]]==0x14)return 0;
		else if(program[program[0]]==0x21)scanf("%d",&program[program[++program[0]]]);
		else if(program[program[0]]==0x22)scanf("%x",&program[program[++program[0]]]);
		else if(program[program[0]]==0x23)printf("%d",&program[program[++program[0]]]);
		else if(program[program[0]]==0x24)printf("%x",&program[program[++program[0]]]);
		else if(program[program[0]]==0x31)
			if(program[program[++program[0]]]>program[program[++program[0]]])program[program[++program[0]]]=1;
			else ++program[0];
		else if(program[program[0]]==0x32)
			if(program[program[++program[0]]]<program[program[++program[0]]])program[program[++program[0]]]=1;
			else ++program[0];
		else if(program[program[0]]==0x33)
			if(program[program[++program[0]]]==program[program[++program[0]]])program[program[++program[0]]]=1;
			else ++program[0];
		else if(program[program[0]]==0x34)
			if(program[program[++program[0]]]!=0)program[0]=program[program[++program[0]]]-1;
			else ++program[0];
		else if(program[program[0]]==0x41)program[program[++program[0]]]=local[0];
		else if(program[program[0]]==0x42)local[0]=program[program[++program[0]]];
		else if(program[program[0]]==0x43)program[program[++program[0]]]=memory[local[0]];
		else if(program[program[0]]==0x44)memory[local[0]]=program[program[++program[0]]];
}