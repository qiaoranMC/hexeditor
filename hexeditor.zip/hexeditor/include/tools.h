#include<stdio.h>
#include<string.h>
#include<conio.h>
int hexdump(int memory[0xffffff],int mode,int start,int end){
	int a=0,b=0,c=0;
	printf("%4x ",start);
	for(a=0;a<=0xf;)
		printf("_%x_",a++);
	for(a=start;a<end;){
		printf("\n  %2x|",a);
		for(c=0;c<0xf;c++)
			printf("%2x ",memory[a++]);
			if(mode==1){
				a-=c;
				for(c=0;c<0xf;c++)
					printf("%2c|",memory[b++]);}}}
int hspcompile(char infile[255]){
	FILE *input,*output;
	char temp[8]={0};
	int a=0,b=0,c=0,memory[65535]={0};
	for(a=0;a<65535;a++)memory[a]=0;
	input=fopen(infile,"r");
	if(input==0)return -1;
	for(a=0;a<4;a++)infile[strlen(infile)-1]=0;
	output=fopen(infile,"w");
	while(a!=-1){
		a=fgetc(input);
		if(a==32||a==10){
			a=strtol(temp,0,16);
			if(a==-1){
				a=0;b=0;
				while(a!=32){
					a=fgetc(input);
					temp[b++]=a;}
				c=strtol(temp,0,16);
			}else memory[c++]=a;
			for(a=0;a<8;a++)temp[a]=0;a=0;b=0;
		}else temp[b++]=a;}
	for(a=0;a<65535;a++)fputc(memory[a],output);
	for(a=0;a<8;a++)temp[a]=0;a=0;b=0;c=0;
	fclose(input);
	fclose(output);
}