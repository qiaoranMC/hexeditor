#include<stdio.h>
#include<stdlib.h>
#include<../include/hexeditor_mod.h>
int initall(){
	for(local[0]=0;local[0]<65535;)memory[local[0]++]=0;
	for(local[0]=1;local[0]<=15;)local[local[0]++]=0;local[0]=0;local[10]=0;local[11]=15;
	scanf("%s",&file);}
int readfile(){
	if(fopen(file,"r")==0)exit(0);
	fp=fopen(file,"r");
	for(local[0]=0;local[0]<65535;)memory[local[0]++]=fgetc(fp);
	local[0]=0;}
int saveall(){
	fclose(fp);
	fp=fopen(file,"w");
	for(local[0]=0;local[0]<65535;){
		fseek(fp,local[0],0);
		fputc(memory[local[0]++],fp);}}
int editmode(){
	while(1){
		system("clear");
		printf("%4x ",local[0]);
		local[2]=0;
		for(local[1]=0;local[1]<=15;)printf("_%x_",local[1]++);
		printf("\t%x-%x",local[10],local[11]);
		for(local[1]=local[10];local[1]<=local[11];){
			printf("\n  %2x|",local[2]++);
	 		for(local[3]=0;local[3]<=15;local[3]++)
				if(local[12]==0)printf("%2x ",memory[local[1]++]);
				else if(local[12]==1)printf("%2d ",memory[local[1]++]);
			if(local[13]==1){
				local[1]-=local[3];
				for(local[3]=0;local[3]<=15;local[3]++)printf("%2c|",memory[local[1]++]);}}
		printf("%4x>>>",local[0]);
		scanf("%x",&local[1]);
		getch();
		if(local[1]==-1){
			scanf("%x",&local[14]);
			scanf("%x",&local[local[14]]);}
		else if(local[1]==-2)script();
		else if(local[1]==-3)saveall();
		else memory[local[0]++]=local[1];}}
int main(){
	initall();
	readfile();
	editmode();
}